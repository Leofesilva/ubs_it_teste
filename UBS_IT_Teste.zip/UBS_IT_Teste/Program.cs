﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace UBS_IT_Teste
{
    public interface ITrade
    {
        double Value { get; }
        string ClientSector { get; }
        DateTime NextPaymentDate { get; }
    }

    // Implementação básica da operação
    public class Trade : ITrade
    {
        public double Value { get; private set; }
        public string ClientSector { get; private set; }
        public DateTime NextPaymentDate { get; private set; }

        public Trade(double value, string clientSector, DateTime nextPaymentDate)
        {
            Value = value;
            ClientSector = clientSector;
            NextPaymentDate = nextPaymentDate;
        }
    }

    // Interface para a categorização das operações
    public interface ITradeCategory
    {
        string GetCategory(ITrade trade, DateTime referenceDate);
    }

    // Categoria 1: EXPIRED
    public class ExpiredCategory : ITradeCategory
    {
        public string GetCategory(ITrade trade, DateTime referenceDate)
        {
            return trade.NextPaymentDate < referenceDate.AddDays(-30) 
                ? "EXPIRED" 
                : null;
        }
    }

    // Categoria 2: HIGHRISK
    public class HighRiskCategory : ITradeCategory
    {
        public string GetCategory(ITrade trade, DateTime referenceDate)
        {
            return trade.Value > 1000000 && trade.ClientSector.Equals("Private", StringComparison.OrdinalIgnoreCase)
                ? "HIGHRISK"
                : null;
        }
    }

    // Categoria 3: MEDIUMRISK
    public class MediumRiskCategory : ITradeCategory
    {
        public string GetCategory(ITrade trade, DateTime referenceDate)
        {
            return trade.Value > 1000000 && trade.ClientSector.Equals("Public", StringComparison.OrdinalIgnoreCase)
                ? "MEDIUMRISK"
                : null;
        }
    }

    // Classe que gerencia a categorização
    public class TradeClassifier
    {
        private readonly List<ITradeCategory> _categories;

        public TradeClassifier()
        {
            _categories = new List<ITradeCategory>
            {
                new ExpiredCategory(),
                new HighRiskCategory(),
                new MediumRiskCategory()
            };
        }

        public string Classify(ITrade trade, DateTime referenceDate)
        {
            foreach (var category in _categories)
            {
                var result = category.GetCategory(trade, referenceDate);
                if (result != null)
                    return result;
            }
            return "UNCATEGORIZED";
        }
    }

    class Program
    {
        static void Main()
        {
            List<ITrade> trades = new List<ITrade>();
            TradeClassifier classifier = new TradeClassifier();

            // Cultura para datas no formato MM/dd/yyyy
            CultureInfo culture = new CultureInfo("en-US");

            try
            {
                Console.WriteLine("Bem vindo ao Classificador de Operações, Siga as instruções a seguir:");
                Console.WriteLine("___");

                // Lê data de referência
                Console.WriteLine("Informe a data de referência. (MM/dd/yyyy)");
                DateTime referenceDate = DateTime.ParseExact(Console.ReadLine(), "MM/dd/yyyy", culture);

                // Lê quantidade de operações
                Console.WriteLine("Informe a quantidade de operações.");
                int n = int.Parse(Console.ReadLine());

                Console.WriteLine("");

                // Lê todas as operações
                for (int i = 0; i < n; i++)
                {
                    // Lê setor publico ou privado
                    Console.WriteLine($"Informe os dados da Operação número {i + 1}: ");
                    Console.WriteLine($"Valor da operação, Setor (Public ou Private) e Data do Próximo Pagamento. Ex: '20000 Public 01/15/2026'");
                    string[] parts = Console.ReadLine().Split(' ');
                    double value = double.Parse(parts[0], CultureInfo.InvariantCulture);
                    string sector = parts[1];
                    DateTime nextPayment = DateTime.ParseExact(parts[2], "MM/dd/yyyy", culture);

                    trades.Add(new Trade(value, sector, nextPayment));
                }

                Console.WriteLine("");
                Console.WriteLine("Segue a categorização das Operações:");

                // Classifica e imprime resultado
                foreach (var trade in trades)
                {
                    Console.WriteLine(classifier.Classify(trade, referenceDate));
                }

                Console.WriteLine("Processamento concluído!");
                Console.ReadKey();
            }
            catch (Exception ex) 
            {
                Console.WriteLine($"Não foi possível processar os dados inseridos, verifique as informações e tente novamente! {ex.Message}");
                Console.ReadKey();
                Console.Clear();
                Main();
            }
        }
    }
}
